from flask import Flask

app = Flask(__name__)


@app.route("/api", methods=["GET"])
def handler():
    return "Esta é a nossa API", 200


if __name__ == "__main__":
    # O servidor de desenvolvimento é útil apenas para testes.
    # Na EC2, o container será iniciado pelo Gunicorn.
    app.run(host="0.0.0.0", port=5000, debug=False)
