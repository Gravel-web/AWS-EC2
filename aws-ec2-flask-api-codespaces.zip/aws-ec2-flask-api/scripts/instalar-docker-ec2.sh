#!/usr/bin/env bash
set -euo pipefail

if [[ "${EUID}" -eq 0 ]]; then
  SUDO=""
else
  SUDO="sudo"
fi

if [[ ! -r /etc/os-release ]]; then
  echo "Não foi possível identificar o sistema operacional."
  exit 1
fi

. /etc/os-release

if [[ "${ID:-}" == "amzn" && "${VERSION_ID:-}" == "2"* ]]; then
  echo "Amazon Linux 2 detectado. Instalando Docker pelo amazon-linux-extras..."
  $SUDO yum update -y
  $SUDO amazon-linux-extras install docker -y
  $SUDO yum install -y git
elif [[ "${ID:-}" == "amzn" && "${VERSION_ID:-}" == "2023"* ]]; then
  echo "Amazon Linux 2023 detectado. Instalando Docker..."
  $SUDO dnf update -y
  $SUDO dnf install -y docker git
else
  echo "Sistema detectado: ${PRETTY_NAME:-desconhecido}"
  echo "Este script foi preparado para Amazon Linux 2 e Amazon Linux 2023."
  echo "Consulte o README para adaptar a instalação a outra distribuição."
  exit 1
fi

$SUDO systemctl enable docker
$SUDO systemctl start docker
$SUDO docker info

echo
echo "Docker instalado e iniciado. Use os comandos Docker com sudo nesta atividade."
