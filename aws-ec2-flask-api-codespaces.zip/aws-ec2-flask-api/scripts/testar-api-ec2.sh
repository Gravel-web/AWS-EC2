#!/usr/bin/env bash
set -euo pipefail

URL="${1:-http://127.0.0.1:5000/api}"
echo "Testando: $URL"
curl --include --fail --show-error "$URL"
