#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
cd "$PROJECT_DIR"

if ! command -v docker >/dev/null 2>&1; then
  echo "Docker não encontrado. Execute antes: ./scripts/instalar-docker-ec2.sh"
  exit 1
fi

if [[ ! -f Dockerfile || ! -f main.py || ! -f requirements.txt ]]; then
  echo "Arquivos do projeto não encontrados. Execute este script na cópia completa do projeto."
  exit 1
fi

echo "Pasta do projeto: $(pwd)"
sudo docker build --tag my-api .

# Remove uma execução anterior com o mesmo nome, se existir.
if sudo docker container inspect main >/dev/null 2>&1; then
  sudo docker rm --force main >/dev/null
fi

sudo docker run --detach --name main --publish 5000:5000 my-api

echo
echo "Container em execução:"
sudo docker container ls

echo
echo "Teste dentro da EC2:"
curl --fail --show-error http://127.0.0.1:5000/api
printf '\n'
