# AWS EC2 Avançado — API Flask com Docker e Gunicorn

Este projeto segue a atividade do PDF do professor: publicar uma API Python/Flask na AWS EC2, executada com Gunicorn dentro de um container Docker.

A rota `GET /api` deve responder exatamente:

```text
Esta é a nossa API
```

## Importante: não precisa instalar Docker no seu computador

Use o **GitHub Codespaces** pelo navegador para guardar/editar os arquivos e usar o terminal remoto. O Docker usado na entrega será instalado e executado **na instância EC2**, não no armazenamento do seu PC.

O Codespaces é um ambiente hospedado na nuvem. A máquina do Codespace tem seus próprios recursos e limites de uso; portanto, evite manter Codespaces abertos quando não estiver usando.

## 1. Colocar o projeto no GitHub

1. Crie um repositório no GitHub (pode ser privado, mas a EC2 precisará ter acesso para clonar; para uma atividade simples, um repositório público facilita).
2. Envie para a raiz do repositório os arquivos e a pasta `scripts` deste projeto. Não envie arquivos `.pem`, senhas ou tokens.
3. Abra o repositório no GitHub e selecione **Code > Codespaces > Create codespace on main**.
4. Quando o Codespace abrir, abra **Terminal > New Terminal**.
5. Confira se os arquivos estão no diretório:

```bash
pwd
ls -la
```

O `Dockerfile`, `main.py`, `requirements.txt` e a pasta `scripts` devem aparecer.

## 2. Salvar os arquivos no repositório pelo terminal do Codespaces

Se você adicionou ou alterou os arquivos dentro do Codespace, salve-os no GitHub:

```bash
git add .
git commit -m "Adicionar projeto AWS EC2 Flask Docker"
git push
```

Se aparecer uma mensagem dizendo que não há alterações, os arquivos já estão salvos.

## 3. Conectar à instância EC2

A atividade exige que a aplicação rode na EC2. Portanto, abra o Console AWS no navegador:

1. Entre em **EC2 > Instances**.
2. Selecione a instância do laboratório.
3. Clique em **Connect > EC2 Instance Connect > Connect** (se esse método estiver habilitado no laboratório).
4. Os próximos comandos desta seção devem ser executados no terminal da EC2, não no terminal do Codespaces.

Não coloque sua chave privada `.pem` no repositório GitHub. Se o laboratório exigir SSH por chave, mantenha a chave privada fora do repositório e siga o procedimento seguro indicado pelo professor.

## 4. Instalar o Docker na EC2

Na EC2, clone o repositório. Troque a URL abaixo pela URL real do seu repositório:

```bash
git clone https://github.com/SEU-USUARIO/SEU-REPOSITORIO.git
cd SEU-REPOSITORIO
```

Se o repositório tiver os arquivos dentro de uma subpasta, entre nela também.

Execute o instalador preparado:

```bash
chmod +x scripts/*.sh
./scripts/instalar-docker-ec2.sh
```

O script reconhece Amazon Linux 2 e Amazon Linux 2023. **Atenção:** o Amazon Linux 2 chegou ao fim do suporte em 30/06/2026. Para uma instância nova, prefira Amazon Linux 2023, a menos que o laboratório/professor exija a AMI antiga.

## 5. Construir e iniciar o container na EC2

Ainda dentro da pasta que contém o `Dockerfile`, execute:

```bash
./scripts/publicar-na-ec2.sh
```

O script executa o `docker build`, cria a imagem `my-api` e inicia o container `main` na porta 5000.

Para conferir manualmente:

```bash
sudo docker images
sudo docker container ls
sudo docker logs main
```

## 6. Liberar a porta 5000 no Security Group

No Console AWS, abra a instância e vá em **Security > Security groups > Inbound rules > Edit inbound rules**. Adicione uma regra:

- Type: Custom TCP
- Port range: `5000`
- Source: seu IP para teste, ou a origem indicada pelo professor/laboratório.

Não deixe a porta aberta para todos sem necessidade. A porta 22 (SSH) também deve ficar restrita ao seu IP, quando aplicável.

## 7. Testar a aplicação

Na EC2:

```bash
./scripts/testar-api-ec2.sh
```

Resposta esperada:

```text
HTTP/1.1 200 OK
...
Esta é a nossa API
```

Depois, no navegador, abra `http://IP_PUBLICO_DA_EC2:5000/api`, trocando pelo IPv4 público da sua instância.

## 8. Comandos solicitados no tutorial para manutenção

```bash
# Containers em execução
sudo docker container ps

# Todos os containers, inclusive parados
sudo docker container ls -a

# Parar o container
sudo docker container stop main

# Iniciar novamente
sudo docker start main

# Listar imagens
sudo docker images -a

# Remover o container (para recriá-lo)
sudo docker rm -f main
```

## Checklist para a entrega

- [ ] Instância EC2 em execução.
- [ ] Docker instalado e ativo (`sudo docker info`).
- [ ] Imagem `my-api` criada (`sudo docker images`).
- [ ] Container `main` em execução (`sudo docker container ls`).
- [ ] Regra TCP 5000 configurada no Security Group.
- [ ] `curl http://127.0.0.1:5000/api` respondeu `Esta é a nossa API`.
- [ ] Endereço público da EC2 abriu a API no navegador.
- [ ] Capturas de tela reais da sua execução foram guardadas.

## Observação sobre o Codespaces

O Codespaces ajuda você a trabalhar pelo navegador e não ocupa o armazenamento local com a imagem/container da atividade. Mas rodar a API apenas no Codespaces **não substitui** a publicação na AWS EC2 pedida pelo professor. A imagem e o container finais deste roteiro são construídos e executados na EC2.
